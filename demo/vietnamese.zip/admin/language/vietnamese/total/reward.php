<?php
// Heading
$_['heading_title']    = 'Điểm thưởng';

// Text
$_['text_total']       = 'Tổng số đơn hàng';
$_['text_success']     = 'Thành công: bạn đã thay đổi tổng số điểm thưởng!';

// Entry
$_['entry_status']     = 'Tình trạng:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi tổng số điểm thưởng!';
?>