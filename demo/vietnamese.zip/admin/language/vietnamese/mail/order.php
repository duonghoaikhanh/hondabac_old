<?php
// Text
$_['text_subject']      = '%s - Cập nhật đơn hàng %s';
$_['text_order']        = 'ID đơn hàng:';
$_['text_date_added']   = 'Thứ tự ngày:';
$_['text_order_status'] = 'Đơn hàng của bạn đã được cập nhật tình trạng dưới đây:';
$_['text_comment']      = 'Các ý kiến ​​cho đơn đặt hàng của bạn:';
$_['text_link']         = 'Để xem đơn hàng của bạn click vào liên kết bên dưới:';
$_['text_footer']       = 'Xin vui lòng trả lời email này nếu bạn có bất kỳ câu hỏi.';
?>