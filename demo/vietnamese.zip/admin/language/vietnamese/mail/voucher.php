<?php
// Text
$_['text_subject']  = 'Bạn đã được gửi một Phiếu Qùa tặng - Voucher từ %s';
$_['text_greeting'] = 'Chúc mừng! Bạn nhận được phiếu Quà Tặng - Voucher trị giá: <b>%s</b>';
$_['text_from']     = 'Phiếu Quà tặng được gửi đến bạn bởi: <b>%s</b>';
$_['text_message']  = 'Với lời nhắn:';
$_['text_redeem']   = 'Để sử dụng Phiếu Quà tặng này, Bạn hãy ghi lại mã <b>%s</b> sau đó bấm vào đường link bên dưới duyệt sản phẩm cần mua và sử dụng mã trên Thanh toán tiền hàng. Trân trọng cám ơn!';
$_['text_footer']   = 'Vui lòng trả lời thư này nếu bạn có bất kì câu hỏi nào.';
?>