<?php
// Text
$_['text_footer'] = 'Hệ thống mã nguồn mở OpenCart phiên bản %s.<br />Gói ngôn ngữ Tiếng Việt phát triển bởi <a href="http://timmanguon.com">wWw.Timmanguon.Com</a>';
?>