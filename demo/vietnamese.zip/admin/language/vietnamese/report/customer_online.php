<?php
// Heading
$_['heading_title']     = 'Khách đang truy cập Website';

// Text 
$_['text_guest']        = 'Khách';
 
// Column
$_['column_ip']         = 'Địa chỉ IP';
$_['column_customer']   = 'Khách hàng';
$_['column_url']        = 'Trang cuối cùng đã xem';
$_['column_referer']    = 'Nguồn truy cập';
$_['column_date_added'] = 'Click lần cuối';
$_['column_action']     = 'Thao tác';
?>