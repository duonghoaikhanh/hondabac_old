<?php
// Heading
$_['heading_title']    = 'IP khách hàng Blacklist';

// Text
$_['text_success']     = 'Thành Công: Bạn đã thay đổi IP khách hàng Blacklist!';

// Column
$_['column_ip']        = 'IP';
$_['column_customer']  = 'Khách hàng';
$_['column_action']    = 'Thao tác';

// Entry
$_['entry_ip']         = 'IP:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền chỉnh sửa IP khách hàng Blacklist!';
$_['error_ip']         = 'IP phải là giữa 1 và 15 ký tự!';
?>