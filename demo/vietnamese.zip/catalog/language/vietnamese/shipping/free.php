<?php
// Text
$_['text_title']       = 'Miễn phí vận chuyển đối với khách hàng nằm trong bán kính 20km';
$_['text_description'] = 'Miễn phí vận chuyển';
?>