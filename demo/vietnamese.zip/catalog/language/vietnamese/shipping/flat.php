<?php
// Text
$_['text_title']       = 'Phí vận chuyển đối với khách hàng ngoài bán kính 20km, chi phí có thể thay đổi';
$_['text_description'] = 'Phí vận chuyển cố định';
?>