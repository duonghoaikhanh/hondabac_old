<?php
$_['text_klarna_fee'] = 'Fee';
?>
