<?php
$_['text_total'] = 'Tổng cộng :';
?>