<?php
// Heading 
$_['heading_title'] = '';

// Text
$_['text_comments']     = 'Based on %s reviews.'; 

?>