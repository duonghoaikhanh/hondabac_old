<?php
// Heading 
$_['heading_title']    = 'Tài khoản';

// Text
$_['text_register']    = 'Đăng ký';
$_['text_login']       = 'Đăng nhập';
$_['text_logout']      = 'Đăng xuất';
$_['text_address']     = 'Địa chỉ';
$_['text_recurring']   = 'Thanh toán định kỳ';
$_['text_forgotten']   = 'Quên Mật Khẩu';
$_['text_account']     = 'Tài Khoản Của Tôi';
$_['text_edit']        = 'Thay đổi tài khoản';
$_['text_password']    = 'Mật khẩu';
$_['text_order']       = 'Lịch sử đặt hàng';
$_['text_wishlist']    = 'Danh sách yêu thích';
$_['text_transaction'] = 'Lịch sử Giao dịch';
$_['text_voucher']     = 'Mua phiếu Quà tặng';
$_['text_return']      = 'Lịch sử Đổi / Trả hàng';
$_['text_newsletter']  = 'Thư thông báo';
$_['text_download']    = 'Tải về';
?>
