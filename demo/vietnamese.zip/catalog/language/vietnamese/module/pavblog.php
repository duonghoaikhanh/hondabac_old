<?php 
$_['text_write_by'] = 'Viết bởi: ';
$_['text_published_in'] = 'Chuyên mục: ';
$_['text_created_date'] = 'Tạo ngày: ';
$_['text_hits'] = 'Lượt xem: ';
$_['text_comment_count'] = 'Bình luận: ';
$_['text_readmore'] = 'Xem tiếp';
$_['text_leave_a_comment'] = 'Bình luận';


 $_['error_captcha'] = 'Nhập mã captcha không chính xác';
 $_['error_email'] = 'Địa chỉ email không đúng';
 $_['error_comment'] = 'Địa chỉ email không đúng';
 $_['error_user'] = 'Họ tên không đúng';
 $_['text_in_related_by_tag'] = 'Bài viết cùng Tags'; 
/**
 *
 */
 $_['text_children'] = 'Mục con';
 $_['text_in_same_category'] = 'Bài cùng chuyên mục';
 $_['text_list_comments'] = 'Bình luận';
 $_['text_created'] = 'Được tạo';
 $_['text_postedby'] = 'Viết bởi';
 $_['text_comment_link'] = 'Gửi bình luận';
 $_['entry_name'] = 'Full Name';
 $_['entry_email'] = 'Email';
 $_['entry_comment'] = 'Nội dung';
 $_['text_submit'] = 'Gửi đi';
 $_['text_tags'] = 'Tags: ';
 
 $_['text_like_this'] = 'Chia sẻ:';
  $_['entry_captcha'] = 'Mã bảo mật';
 /**
  *
  */
  $_['filter_blog_header_title'] = 'Lọc bài viết theo %s';
  $_['blogs_latest_header_title'] = 'Bài viết mới';

  /*blogcategory module*/
  // Heading 
$_['blog_category_heading_title'] = 'Danh mục';

// Text
$_['text_latest']  = 'Tin mới'; 
$_['text_mostviewed']  = 'Tin xem nhiều'; 
$_['text_featured']  = 'Tin nổi bật'; 
$_['text_bestseller']  = 'Best Seller'; 

/*blogcomment module*/
// Heading 
$_['blogcomment_heading_title'] = 'Bình luận mới nhất';

$_['text_postedby'] = 'Gửi bởi';
/*bloglatest module*/
// Heading 
$_['bloglatest_heading_title'] = 'Tin mới nhất';

// Text
$_['text_latest']  = 'Tin mới nhất'; 
$_['text_mostviewed']  = 'Tin xem nhiều'; 
$_['text_featured']  = 'Tin nổi bật'; 
$_['text_bestseller']  = 'Được mua nhiều'; 
$_['entry_show_readmore'] = 'Hiện Readmore' ;
$_['text_readmore'] = 'Xem tiếp' ;
$_['text_error'] = 'Không tìm thấy bài viết trong chuyên mục' ;
?>