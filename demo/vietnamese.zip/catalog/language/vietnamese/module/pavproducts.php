<?php
/******************************************************
 * @package Pav Product Tabs module for Opencart 1.5.x
 * @version 1.0
 * @author http://www.pavothemes.com
 * @copyright	Copyright (C) Feb 2012 PavoThemes.com <@emai:pavothemes@gmail.com>.All rights reserved.
 * @license		GNU General Public License version 2
*******************************************************/
// Heading 
$_['heading_title'] = 'Sản phẩm mới';

// Text
$_['text_latest']  = 'Sản phẩm mới'; 
$_['text_mostviewed']  = 'Được xem nhiều'; 
$_['text_featured']  = 'Sản phẩm nổi bật'; 
$_['text_bestseller']  = 'Được mua nhiều'; 
$_['text_special']  = 'Sản phẩm khuyến mại';

$_['text_sale'] = 'Sale';
$_['text_sale_detail'] = 'Tiết kiệm: %s';
?>