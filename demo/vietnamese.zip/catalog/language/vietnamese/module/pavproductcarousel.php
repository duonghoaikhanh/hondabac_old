<?php
// Heading 
$_['heading_title'] = 'Sản phẩm mới';

// Text
$_['text_latest']  = 'Sản phẩm mới'; 
$_['text_mostviewed']  = 'Được xem nhiều'; 
$_['text_featured']  = 'Sản phẩm nổi bật'; 
$_['text_bestseller']  = 'Được mua nhiều'; 
$_['text_special']  = 'Sản phẩm khuyến mại';
$_['text_toprating']  = 'Đánh giá cao'; 

$_['text_sale'] = 'Sale';
$_['text_sale_detail'] = 'Tiết kiệm: %s';
?>
