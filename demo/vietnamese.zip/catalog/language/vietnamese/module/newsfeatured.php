<?php
// Heading 
$_['heading_title'] = 'Tin tức nổi bật';

// Text
$_['text_comments']  = 'Dựa trên %s đánh giá.'; 
?>