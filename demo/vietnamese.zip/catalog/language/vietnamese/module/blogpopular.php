<?php
$_['heading_title']     = 'Popular Articles';
?>