﻿<?php
// Heading 
$_['heading_title']    = 'Liên kết - Affiliate';

// Text
$_['text_register']    = 'Đăng ký';
$_['text_login']       = 'Đăng nhập';
$_['text_logout']      = 'Đăng xuất';
$_['text_forgotten']   = 'Quên mật khẩu';
$_['text_account']     = 'Tài khoản của tôi';
$_['text_tracking']    = 'Mã giới thiệu';
$_['text_transaction'] = 'Thống kê';
$_['text_payment']     = 'Tùy chọn thanh toán';
$_['text_edit']        = 'Thay đổi thông tin';
$_['text_password']    = 'Thay đổi mật khẩu';
?>
