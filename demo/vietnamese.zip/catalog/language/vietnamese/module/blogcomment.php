<?php
$_['heading_title']     = 'Latest Comments';

$_['text_comment_on']   = 'on';
?>