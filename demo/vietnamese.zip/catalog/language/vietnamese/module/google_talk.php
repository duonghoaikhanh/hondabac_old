<?php
// Heading 
$_['heading_title']  = 'Chăm sóc khách hàng';
?>