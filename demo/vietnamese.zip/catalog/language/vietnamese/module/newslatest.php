<?php
// Heading
$_['heading_title'] = 'Tin tức mới';

// Text
$_['text_comments']  = 'Dựa trên %s đánh giá.';
?>