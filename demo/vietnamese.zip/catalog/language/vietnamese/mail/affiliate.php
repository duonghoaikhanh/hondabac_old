<?php
// Text
$_['text_subject']  = '%s - Chương Trình Đại lý';
$_['text_welcome']  = 'Cám ơn bạn đã tham gia chương trình Đại lý của Thực Phẩm Bồi Bổ!';
$_['text_approval'] = 'Bạn có thể đăng nhập vào tài khoản Đại lý bằng email và mật khẩu theo đường dẫn sau:';
$_['text_services'] = 'Khi đăng nhập bạn có thể xem mã Đại lý, tạo các link giới thiệu của mình và theo dõi tiền Hoa hồng...';
$_['text_thanks']   = 'Trân trọng cám ơn! Chúc Bạn phát triển được nhiều Đại lý khác & luôn đạt doanh số cao nhất!';
?>