<?php
// Text
$_['text_subject']  = 'Bạn đã gửi phiếu quà tặng từ %s';
$_['text_greeting'] = 'Chúc mừng, Bạn nhận được phiếu Quà Tặng - Voucher trị giá %s';
$_['text_from']     = 'Phiếu Quà tặng được gửi đến bạn bởi %s';
$_['text_message']  = 'Với lời nhắn';
$_['text_redeem']   = 'Để sử dụng Phiếu Quà Tặng hãy ghi lại mã <b>%s</b> sau đó bấm vào đường link bên dưới để duyệt sản phẩm bạn muốn mua và sử dụng mã trên để thanh toán tiền hàng. Bạn cũng có thể nhập mã Phiếu Quà Tặng trong trang Giỏ hàng trước khi thực hiện Thanh toán.';
$_['text_footer']   = 'Vui lòng trả lời thư này nếu bạn có bất kì câu hỏi nào.';
?>