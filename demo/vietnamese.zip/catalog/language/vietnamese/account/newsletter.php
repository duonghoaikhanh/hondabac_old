<?php
// Heading 
$_['heading_title']    = 'Đăng ký nhận thư thông báo & các chương trình Quà tặng, Khuyến mại';

// Text
$_['text_account']     = 'Tài khoản';
$_['text_newsletter']  = 'Thư thông báo';
$_['text_success']     = 'Thành công: Bạn đã đăng ký nhận thư thông báo & các chương trình Quà tặng, Khuyến mại!';

// Entry
$_['entry_newsletter'] = 'Đăng ký:';
?>
