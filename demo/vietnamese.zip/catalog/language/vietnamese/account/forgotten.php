<?php
// Heading 
$_['heading_title']   = 'Bạn Quên Mật khẩu?';

// Text
$_['text_account']    = 'Tài Khoản';
$_['text_forgotten']  = 'Quên Mật khẩu';
$_['text_your_email'] = 'Địa chỉ E-Mail của bạn';
$_['text_email']      = 'Nhập địa chỉ email đã đăng ký với tài khoản này. Bấm nút <b>Tiếp tục</b> mật khẩu sẽ được gửi đến email của bạn';
$_['text_success']    = 'Thành công: mật khẩu mới đã được gửi đến email của bạn!';

// Entry
$_['entry_email']     = 'Địa chỉ E-Mail:';

// Error
$_['error_email']     = 'Lỗi: Địa chỉ email này không có trong dữ liệu của chúng tôi! Vui lòng thử lại!';
?>