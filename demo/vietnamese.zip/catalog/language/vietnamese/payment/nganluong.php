<?php
/*
Đã test chạy tốt trên OpenCart 1.5.5.1 (cả localhost và hosting)
*/
$_['text_title'] = '<img src="/image/data/ngan-luong.gif" /> Thanh toán trực tuyến qua NganLuong.vn';
?>