<?php
// Text
$_['text_title']       = '<img src="/image/data/bank-tranfer.png" /> Chuyển khoản ngân hàng';
$_['text_instruction'] = 'Hướng dẫn chuyển khoản ngân hàng';
$_['text_description'] = 'Vui lòng chuyển khoản tổng tiền cần thanh toán đến tài khoản sau.';
$_['text_payment']     = 'Sản phẩm bạn không được vận chuyển cho đến khi bạn thanh toán.';
?>