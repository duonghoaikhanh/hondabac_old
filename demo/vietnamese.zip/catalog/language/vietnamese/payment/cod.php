<?php
// Text
$_['text_title'] = '<img src="/image/data/pay-giao-nhan.png" /> Thu tiền khi giao hàng';
?>