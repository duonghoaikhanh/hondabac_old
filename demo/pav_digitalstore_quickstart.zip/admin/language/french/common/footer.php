<?php
// Text
$_['text_footer']	= '<a href="http://www.opencart-france.com" target="_blank">OpenCart</a> &copy; 2009-' . date('Y') . ' Tous droits r&eacute;serv&eacute;s.<br />Version %s';
?>