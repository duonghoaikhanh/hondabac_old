<?php
// Heading
$_['heading_title']		= 'Modules';

// Text
$_['text_install']		= 'Installer';
$_['text_uninstall']	= 'D&eacute;sinstaller';

// Column
$_['column_name']		= 'Nom du module';
$_['column_action']		= 'Action';

// Error
$_['error_permission']	= 'Attention, vous n&#8217;avez la permission de modifier les <b>Modules</b> !';
?>