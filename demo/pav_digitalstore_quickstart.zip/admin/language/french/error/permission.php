<?php
// Heading
$_['heading_title']		= 'Permission refus&eacute;e !';

// Text
$_['text_permission']	= 'Vous n&#8217;avez pas la permission d&#8217;acc&egrave;der &agrave; cette page, veuillez vous adresser &agrave; votre administrateur syst&egrave;me.';
?>