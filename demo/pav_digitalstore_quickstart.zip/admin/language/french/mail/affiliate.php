<?php
// Text
$_['text_approve_subject']		= '%s - Votre compte affili&eacute; a &eacute;t&eacute; activ&eacute; !';
$_['text_approve_welcome']		= 'Nous vous souhaitons bienvenue et vous remercions de votre enregistrement sur %s !';
$_['text_approve_login']		= 'Votre compte a &eacute;t&eacute; cr&eacute;&eacute; et vous pouvez vous connecter en utilisant votre adresse courriel et mot de passe en visitant notre site Web ou &agrave; l&#8217;adresse suivante :';
$_['text_approve_services']		= 'Lors de la connexion, vous serez en mesure de g&eacute;n&eacute;rer des codes de suivi, suivre le paiement des commission piste et modifier vos informations de compte.';
$_['text_approve_thanks']		= 'Merci,';
$_['text_transaction_subject']	= '%s - Commission des affiliations';
$_['text_transaction_received']	= 'Vous avez re&ccedil:u %s commission !';
$_['text_transaction_total']	= 'Le montant total de vos commissions est de %s.';
?>