<?php
// Text
$_['text_subject']	= '%s - R&eacute;initialisation du mot de passe requis';
$_['text_greeting']	= 'Un nouveau mot de passe a &eacute;t&eacute; demand&eacute; pour l&#8217;administration de %s .';
$_['text_change']	= 'Pour r&eacute;initialiser votre mot de passe, cliquez sur le lien ci-dessous :';
$_['text_ip']		= 'L&#8217;adresse IP utilis&eacute;e pour faire cette demande &eacute;tait :';
?>