<?php
// Text
$_['text_subject']		= '%s - Mise &agrave; jour de la commande %s';
$_['text_order']		= 'N&deg; de commande :';
$_['text_date_added']	= 'Date de commande :';
$_['text_order_status']	= 'Votre commande a &eacute;t&eacute; mise &agrave; jour avec l&#8217;&eacute;tat suivant :';
$_['text_comment']		= 'Les commentaires pour cette commande sont :';
$_['text_link']			= 'Pour consulter votre commande, cliquer sur le lien ci-dessous :';
$_['text_footer']		= 'Veuillez r&eacute;pondre &agrave; ce message si vous avez des questions.';
?>