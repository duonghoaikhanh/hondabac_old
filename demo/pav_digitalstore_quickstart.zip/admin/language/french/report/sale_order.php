<?php
// Heading
$_['heading_title']		= 'Rapport sur les ventes';

// Text
$_['text_year']			= 'Ann&eacute;es';
$_['text_month']		= 'Mois';
$_['text_week']			= 'Semaines';
$_['text_day']			= 'Jours';
$_['text_all_status']	= 'Tous les &eacute;tats';

// Column
$_['column_date_start']	= 'Date de d&eacute;but';
$_['column_date_end']	= 'Date de fin';
$_['column_orders']		= 'Nombre de commande';
$_['column_products']	= 'Nombre de produit';
$_['column_tax']		= 'Taxe';
$_['column_total']		= 'Total';

// Entry
$_['entry_date_start']	= 'Date de d&eacute;but :';
$_['entry_date_end']	= 'Date de fin :';
$_['entry_group']		= 'Regrouper par :';
$_['entry_status']		= '&Eacute;tat de la commande:';
?>