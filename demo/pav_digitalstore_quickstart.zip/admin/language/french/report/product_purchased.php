<?php
// Heading
$_['heading_title']		= 'Rapport sur les produits achet&eacute;s';

// Text
$_['text_all_status']	= 'Tous les &eacute;tats';

// Column
$_['column_date_start']	= 'Date de d&eacute;but';
$_['column_date_end']	= 'Date de fin';
$_['column_name']		= 'Nom du produit';
$_['column_model']		= 'Mod&egrave;le';
$_['column_quantity']	= 'Quantit&eacute;';
$_['column_total']		= 'Total';

// Entry
$_['entry_date_start']	= 'Date de d&eacute;but :';
$_['entry_date_end']	= 'Date de fin :';
$_['entry_status']		= '&Eacute;tat de la commande :';
?>