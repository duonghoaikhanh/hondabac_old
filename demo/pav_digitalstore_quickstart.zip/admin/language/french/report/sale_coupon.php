<?php
// Heading
$_['heading_title']		= 'Rapport sur les coupons';

// Column
$_['column_name']		= 'Nom du coupon';
$_['column_code']		= 'Code';
$_['column_orders']		= 'Commandes';
$_['column_total']		= 'Total';
$_['column_action']		= 'Action';

// Entry
$_['entry_date_start']	= 'Date de d&eacute;but :';
$_['entry_date_end']	= 'Date de fin :';
?>