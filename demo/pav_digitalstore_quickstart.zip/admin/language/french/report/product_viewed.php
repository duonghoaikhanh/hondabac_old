<?php
// Heading
$_['heading_title']	= 'Rapport sur les produits les plus consult&eacute;s';

// Text
$_['text_success']	= 'F&eacute;licitations, vous avez remis &agrave; z&eacute;ro le <b>Rapport sur les produits les plus consult&eacute;s</b> avec succ&egrave;s !';

// Column
$_['column_name']	= 'Nom du produit';
$_['column_model']	= 'Mod&egrave;le';
$_['column_viewed']	= 'Nombre de consultations';
$_['column_percent']= 'Pourcentage';
?>