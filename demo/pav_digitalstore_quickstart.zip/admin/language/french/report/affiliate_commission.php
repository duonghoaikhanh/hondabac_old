<?php
// Heading
$_['heading_title']		= 'Rapport sur les commissions affili&eacute;';

// Column
$_['column_affiliate']	= 'Nom de l&#8217;affili&eacute;';
$_['column_email']		= 'Courriel';
$_['column_status']		= '&Eacute;tat';
$_['column_commission']	= 'Commission';
$_['column_orders']		= 'Nombre de commande';
$_['column_total']		= 'Total';
$_['column_action']		= 'Action';

// Entry
$_['entry_date_start']	= 'Date de d&eacute;but :';
$_['entry_date_end']	= 'Date de fin :';
?>