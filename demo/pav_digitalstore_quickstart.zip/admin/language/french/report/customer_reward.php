<?php
// Heading
$_['heading_title']			= 'Rapport sur les points de fidelit&eacute; client';

// Column
$_['column_customer']		= 'Nom du client';
$_['column_email']			= 'Courriel';
$_['column_customer_group']	= 'Groupe clients';
$_['column_status']			= '&Eacute;tat';
$_['column_points']			= 'Points de fidelit&eacute;';
$_['column_orders']			= 'Nombre de commande';
$_['column_total']			= 'Total';
$_['column_action']			= 'Action';

// Entry
$_['entry_date_start']		= 'Date de d&eacute;but :';
$_['entry_date_end']		= 'Date de fin :';
?>