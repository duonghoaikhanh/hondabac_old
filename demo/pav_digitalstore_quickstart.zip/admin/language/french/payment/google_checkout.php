<?php
// Heading
$_['heading_title']			= 'Google Checkout';

// Text
$_['text_payment']			= 'Paiement';
$_['text_success']			= 'F&eacute;licitations, vous avez modifi&eacute; Google Checkout!';

// Entry
$_['entry_merchant_id']		= 'N&deg; d&#8217;identification marchand :';
$_['entry_merchant_key']	= 'Cl&eacute; marchand :';
$_['entry_currency']		= 'Devise :';
$_['entry_test']			= 'Mode de test :';
$_['entry_status']			= '&Eacute;tat :';

// Error
$_['error_permission']		= 'Attention, vous n&#8217;avez pas la permission de modifier Google Checkout!';
$_['error_merchant_id']		= 'Attention, le N&deg; d&#8217;identification marchand  est requis !';
$_['error_merchant_key']	= 'Attention, la cl&eacute; marchand est requise !';
?>