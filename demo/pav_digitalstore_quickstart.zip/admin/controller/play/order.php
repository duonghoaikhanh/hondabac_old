<?php
class ControllerPlayOrder extends Controller {
    public function ajaxShippingInfo(){

    }

    public function ajaxAddShippingInfo(){

    }
}
