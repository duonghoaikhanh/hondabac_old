<?php
// Text
$_['text_home']     = 'Trang chủ';
$_['text_wishlist'] = 'Yêu thích (%s)';
$_['text_cart']     = 'Giỏ hàng';
$_['text_shopping_cart']  = 'Giỏ hàng';
$_['text_items']    = '%s sản phẩm(s) - %s';
$_['text_search']   = 'Tìm kiếm';
$_['text_welcome']  = 'Xin chào! Bạn có thể <a href="%s">Đăng Nhập</a> hoặc <a href="%s">tạo Tài Khoản</a>';
$_['text_logged']   = 'Bạn đã đăng nhập với tên <a href="%s">%s</a> <b>(</b> <a href="%s">Thoát ra</a> <b>)</b>';
$_['text_account']  = 'Tài khoản';
$_['text_checkout'] = 'Thanh toán';
$_['text_language'] = 'Ngôn ngữ';
$_['text_currency'] = 'Tiền tệ';
?>