<?php
// Text
$_['text_title']       = 'Chuyển tiền qua bưu điện / Séc';
$_['text_instruction'] = 'HƯỚNG DẪN CHUYỂN TIỀN QUA BƯU ĐIỆN / SÉC';
$_['text_payable']     = 'Vui lòng gửi tiền Mua hàng và tiền Cước vận chuyển (nếu có) cho: ';
$_['text_address']     = 'Địa chỉ: ';
$_['text_payment']     = 'Điện thoại: 0987.82.76.45 hoặc 0904.50.12.16<p>Hàng của bạn sẽ chưa đưa đi cho tới khi chúng tôi nhận được thanh toán.';
?>