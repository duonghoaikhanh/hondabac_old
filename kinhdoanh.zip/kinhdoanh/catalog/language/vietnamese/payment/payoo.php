<?php
// Text
$_['text_title'] = 'Thanh toán trực tuyến payoo <br /><img src="https://www.payoo.com.vn/data/interface/v1_0/img/themes/main/logo.jpg" />';
?>