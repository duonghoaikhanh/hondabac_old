<?php
// Text
$_['text_title'] = 'PayPal Express (Bao gồm thẻ tín dụng và thẻ ghi nợ)';
?>