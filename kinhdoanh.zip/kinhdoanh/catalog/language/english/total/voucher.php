<?php
// Text
$_['text_voucher'] = 'Voucher(%s)';
?>